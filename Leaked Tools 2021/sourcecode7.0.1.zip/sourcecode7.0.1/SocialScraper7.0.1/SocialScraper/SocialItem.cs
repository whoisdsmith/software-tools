﻿namespace SocialScraper
{
    public class SocialItem
    {
        public string Name { get; set; }
        public string Site { get; set; }
    }
}
